/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */

import com.mycompany.part2.Task;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author hp
 */
public class TaskTest {
    private Task task1;
    private Task task2;
    public TaskTest() {
        task1 = new Task("Login Feature", "Create Login to authenticate users", "Mike Smith", 8, "To Do", 0);
        task2 = new Task("Add Feature", "Create Add Task feature to add tasks", "Mike Smith", 10, "Doing", 1);
    }
 @Test
    public void testTask1Description() {
        assertTrue(task1.checkTaskDescription(), "Task 1 description should be valid (<= 50 characters).");
    }

 
    @Test
    public void testTask2Description() {
        assertTrue(task2.checkTaskDescription(), "Task 2 description should be valid (<= 50 characters).");
    }


    @Test
    public void testTask1IDGeneration() {
        assertEquals("LO:0:SON", task1.getTaskID(), "Task 1 ID should be 'LO:0:SON' (Login Feature, Mike Smith).");
    }

 
    @Test
    public void testTask2IDGeneration() {
        assertEquals("AD:1:ITH", task2.getTaskID(), "Task 2 ID should be 'AD:1:ITH' (Add Feature, Mike Smith).");
    }

  
    @Test
    public void testTask1FullDetails() {
        String expectedDetails = "Task Status: To Do" +
                "\nDeveloper Details: Mike Smith" +
                "\nTask Number: 0" +
                "\nTask Name: Login Feature" +
                "\nTask Description: Create Login to authenticate users" +
                "\nTask ID: LO:0:SON" +
                "\nTask Duration: 8 hours";

        assertEquals(expectedDetails, task1.printTaskDetails(), "Task 1 details should match the expected output.");
    }

 
    @Test
    public void testTask2FullDetails() {
        String expectedDetails = "Task Status: Doing" +
                "\nDeveloper Details: Mike Smith" +
                "\nTask Number: 1" +
                "\nTask Name: Add Feature" +
                "\nTask Description: Create Add Task feature to add tasks" +
                "\nTask ID: AD:1:ITH" +
                "\nTask Duration: 10 hours";

        assertEquals(expectedDetails, task2.printTaskDetails(), "Task 2 details should match the expected output.");
    }


    @Test
    public void testTotalTaskDuration() {
        assertEquals(18, Task.returnTotalHours(), "Total task duration should be 18 hours (8 + 10).");
    }
}
